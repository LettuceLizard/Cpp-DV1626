#pragma once

enum class VinylTypes {LONG_PLAY, EXTENDED_PLAY};
